# ✋ Sign Language Recognition Using MediaPipe, Logistic Regression & gTTS (with pygame)

A real-time Sign Language Recognition system that uses:

- **MediaPipe** to detect hand landmarks  
- **Logistic Regression** to classify signs  
- **gTTS + pygame** to convert predictions into speech  
- **CSV-based dataset** collected from user recordings  
- **Thread-based TTS** so audio plays smoothly while the webcam runs  

This project converts simple hand gestures into **spoken words**.

---

## 🚀 Quick Start

1. Install requirements:
```
pip install -r requirements.txt
```

2. Collect data:
```
python src/sign_data_collector.py
```

3. Train the model:
```
python src/train_sign_model.py
```

4. Run real-time demo:
```
python src/gtts_model.py
```

---

## 📂 Project Structure

```
sign_language_project/
├── src/
│   ├── gtts_model.py              # Main real-time prediction + TTS (gTTS + pygame)
│   ├── sign_data_collector.py     # Collect your hand sign data (CSV)
│   └── train_sign_model.py        # Train Logistic Regression model
│
├── sign_model.pkl                 # (Optional) Trained model (if you want to upload)
├── scaler.pkl                     # (Optional) Saved StandardScaler
├── sign_data/                     # Folder with CSV datasets (upload if available)
├── images/                        # Add screenshots here (optional)
├── requirements.txt
└── README.md
```

---

## 📝 About the scripts

- **src/sign_data_collector.py** — records wrist-relative landmarks to CSV. Press `s` to start/pause recording and `q` to quit. (Each row has 63 features: 21 landmarks × 3 coordinates.)

- **src/train_sign_model.py** — loads all CSV files from `sign_data/`, scales features, trains a Logistic Regression model, and saves `sign_model.pkl` and `scaler.pkl`.

- **src/gtts_model.py** — real-time webcam loop using MediaPipe; predicts gestures using the trained model; uses gTTS to create an MP3 and `pygame.mixer` to play audio in a background thread to avoid blocking the webcam.

---

## 🔊 Notes on TTS
This project uses **gTTS** (writes a temporary MP3) + **pygame.mixer** for playback, which is robust across platforms. Make sure your system has audio support and that `pygame` dependencies are installed.

---

## 📦 Requirements
Contents of `requirements.txt`:
```
opencv-python
mediapipe
numpy
scikit-learn
gtts
pygame
```

---

## 📸 Screenshots
Add demo screenshots to the `images/` folder and reference them in this README using Markdown.

---

## 🧾 License
MIT — free for educational and personal use.

