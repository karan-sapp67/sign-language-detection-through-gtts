import cv2
import mediapipe as mp
import numpy as np
import pickle
import threading
import time
import os
from collections import deque
from gtts import gTTS
import pygame

# -------- CONFIG --------
CONFIDENCE_MIN = 0.8
SPEAK_ON_NEUTRAL = False
SMOOTHING_WINDOW = 5
# ------------------------

# Load trained model and scaler
with open('sign_model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.6
)
mp_draw = mp.solutions.drawing_utils

current_label = "No Hand"
label_lock = threading.Lock()
tts_thread_running = True
recent_labels = deque(maxlen=SMOOTHING_WINDOW)

# --- TTS and Audio ---
def play_audio(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)
    pygame.mixer.music.unload()
    pygame.mixer.quit()
    if os.path.exists(file_path):
        os.remove(file_path)

def tts_thread_func():
    last_label = None
    while tts_thread_running:
        with label_lock:
            label = current_label

        if label and label != last_label:
            last_label = label

            # Skip saying "Neutral" or "No Hand"
            if label.lower() in ["neutral", "no hand"]:
                continue

            try:
                tts = gTTS(text=label, lang='en')
                tts.save("output.mp3")
                play_audio("output.mp3")
            except Exception as e:
                print(f"TTS Error: {e}")

        elif not label:
            last_label = None

        time.sleep(0.10)

# Start threaded TTS loop
tts_thread = threading.Thread(target=tts_thread_func, daemon=True)
tts_thread.start()

# Webcam loop
cap = cv2.VideoCapture(0)
print("👋 Press 'Q' or 'ESC' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(image)
    label = "No Hand"  # Default when no hand is detected

    if result.multi_hand_landmarks:
        for hand_landmarks in result.multi_hand_landmarks:
            mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

            # Normalize relative to wrist
            wrist = hand_landmarks.landmark[0]
            landmarks = []
            for lm in hand_landmarks.landmark:
                landmarks.extend([lm.x - wrist.x, lm.y - wrist.y, lm.z - wrist.z])

            # Scale data like training
            X = scaler.transform([landmarks])
            pred = model.predict(X)
            conf = max(model.predict_proba(X)[0])

            if conf >= CONFIDENCE_MIN:
                label = pred[0]
            else:
                label = "Neutral"

    # Temporal smoothing (stable predictions)
    if label:
        recent_labels.append(label)
        if len(recent_labels) == SMOOTHING_WINDOW and len(set(recent_labels)) == 1:
            with label_lock:
                current_label = label
    else:
        recent_labels.clear()
        with label_lock:
            current_label = "No Hand"

    cv2.putText(frame, str(current_label), (30, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
    cv2.imshow("Sign Language Recognition", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == 27 or key == ord('q'):  # ESC or Q
        break

tts_thread_running = False
tts_thread.join(timeout=1)
cap.release()
cv2.destroyAllWindows()
print("👋 Program closed.")
