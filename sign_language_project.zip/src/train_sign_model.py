import os
import csv
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
print("Current working directory:", os.getcwd())

DATA_DIR = 'sign_data'

X = []
y = []

# Load all CSV data
for file in os.listdir(DATA_DIR):
    if file.endswith('.csv'):
        label = file.replace('.csv', '')
        with open(os.path.join(DATA_DIR, file)) as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) == 63:  # 21 landmarks × 3 coords
                    X.append(list(map(float, row)))
                    y.append(label)

X = np.array(X)
y = np.array(y)

# Normalize features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LogisticRegression(max_iter=2000)
model.fit(X_train, y_train)

print(f"✅ Training accuracy: {model.score(X_train, y_train):.2f}")
print(f"✅ Test accuracy: {model.score(X_test, y_test):.2f}")

# Save model + scaler
with open('sign_model.pkl', 'wb') as f:
    pickle.dump(model, f)
with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

print("✅ Model and scaler saved!")
