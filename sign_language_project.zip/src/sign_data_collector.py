import cv2
import mediapipe as mp
import csv
import os
import time

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

# Create folder to save data
DATA_DIR = 'sign_data'
os.makedirs(DATA_DIR, exist_ok=True)

# Ask for the sign label
label = input("Enter the sign label (e.g., A, B, Hello, Neutral): ")

file_path = os.path.join(DATA_DIR, f'{label}.csv')

# Open video capture
cap = cv2.VideoCapture(0)

print("Press 's' to start/pause recording, 'q' to quit.")
recording = False
sample_count = 0

with open(file_path, mode='a', newline='') as f:
    csv_writer = csv.writer(f)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = hands.process(rgb_frame)

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                if recording:
                    # Normalize landmarks relative to wrist to make scale/position invariant
                    wrist = hand_landmarks.landmark[0]
                    landmarks = []
                    for lm in hand_landmarks.landmark:
                        landmarks.extend([
                            lm.x - wrist.x,
                            lm.y - wrist.y,
                            lm.z - wrist.z
                        ])
                    csv_writer.writerow(landmarks)
                    sample_count += 1

        # Display info
        color = (0, 255, 0) if recording else (0, 0, 255)
        cv2.putText(frame, f'Sign: {label} | Samples: {sample_count}', (10, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

        cv2.imshow("Sign Data Collector", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('s'):
            recording = not recording
            print("Recording started" if recording else "Recording paused")
        elif key == ord('q'):
            break

cap.release()
cv2.destroyAllWindows()
print(f"✅ Saved {sample_count} samples for '{label}' to {file_path}")
